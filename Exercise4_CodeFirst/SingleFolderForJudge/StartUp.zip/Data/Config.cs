﻿
namespace P01_HospitalDatabase.Data
{
   public class Config
    {
        public const string connectionString = "Server=.;Database=Hospital;Integrated Security=True";
    }
}
