﻿namespace P01_StudentSystem.Data
{
    public static class Config
    {
        public const string connectionString =
            "Server=.;Database=StudentSystem;Integrated Security=True";
    }
}
