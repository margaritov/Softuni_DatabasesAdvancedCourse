﻿
namespace VaporStore.Data.Models
{
    public enum CardType
    {
        Debit = 1, Credit = 2
    }
}
